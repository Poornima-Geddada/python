import turtle

title = "Choose all Indian state"
image = "blank_Indian_map.gif"
score = 0

screen = turtle.Screen()
screen.setup(width=600, height=720)

screen.title(title)
screen.addshape(image)
turtle.shape(image)
screen.listen()

def cords(x, y):
    print(x, y)

turtle.onscreenclick(cords)
turtle.mainloop()
