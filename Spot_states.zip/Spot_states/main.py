import turtle
import pandas

title = "Choose all Indian states"
# title = "Choose all American states"
csv = "Indian_states.csv"
# csv = "50_states.csv"
image = "blank_Indian_map.gif"
# image = "blank_states_img.gif"
score = 0

screen = turtle.Screen()
screen.setup(width=600, height=700)  # india
# screen.setup(width=730, height=520)  # usa
data = pandas.read_csv(csv)
screen.title(title)
screen.addshape(image)
turtle.shape(image)
display_state = turtle.Turtle()
display_state.penup()
display_state.hideturtle()

state_names = data["state"]
correct_states = []

while score < len(data):
    answer_state = turtle.textinput(title=f"{score}/{len(data)} Guess the state", prompt="Enter the next state name?")
    if answer_state is None:
        break
    cap_ans = answer_state.title()
    if cap_ans == "Restart":
        score = 0
        correct_states = []
        screen.clear()
        turtle.shape(image)

    for state in state_names:
        if cap_ans == state:
            correct_states.append(state)
            score += 1
            all_details = data[state_names == cap_ans]
            x_cords = int(all_details["x"])
            y_cords = int(all_details["y"])
            display_state.goto(x_cords, y_cords)
            display_state.color("green")
            display_state.write(cap_ans, align="center", font=("arial", 8, "bold"))

for state in state_names:
    if state not in correct_states:
        all_details = data[state_names == state]
        x_cords = int(all_details["x"])
        y_cords = int(all_details["y"])
        display_state.goto(x_cords, y_cords)
        display_state.color("orange")
        display_state.write(state, align="center", font=("arial", 8, "bold"))

display_state.goto(101, 200)  # india
# display_state.goto(150, -250)  # usa
display_state.color("blue")
display_state.write(f"Your Score = {score}", align="center", font=("arial", 15, "underline"))

screen.exitonclick()
