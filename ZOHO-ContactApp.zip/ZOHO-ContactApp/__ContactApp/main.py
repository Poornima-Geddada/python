import pandas
import csv
from tkinter import *
import login_success

window = Tk()

window.geometry("400x540")
window.minsize(400, 540)
window.maxsize(400, 540)
window.title("Contacts App")

# CSV file handling

users_data = pandas.read_csv("user_info.csv")
all_mails = users_data["u_mail"]

# commands


def access():
    window.destroy()
    login_success.save()
    login_success.table()


def adding_user():
    message = Label(window, text="", font=("Arial", 10, "bold"))
    email = email_input.get()
    password = password_input.get()
    secret = secret_input.get()
    email_input.delete(0, 'end')
    password_input.delete(0, 'end')
    secret_input.delete(0, 'end')
    go_on = True
    if email == "" or password == "" or secret == "":
        message.config(text="Enter all details.", fg="red")
        message.place(x=60, y=450)
        message.after(3000, lambda: message.place_forget())
        go_on = False
    elif email[-10::] != "@gmail.com":
        message.config(text="Enter a proper email.", fg="red")
        message.place(x=60, y=450)
        message.after(3000, lambda: message.place_forget())
        go_on = False
    elif len(password) < 8:
        message.config(text="Try a stronger pass word with 8 or more characters.", fg="blue")
        message.place(x=35, y=450)
        message.after(3000, lambda: message.place_forget())
        go_on = False
    for mail in all_mails:
        if email == mail:
            message.config(text="This email is already in use. Try another mail or sign in.", fg="red")
            message.place(x=60, y=450)
            message.after(3000, lambda: message.place_forget())
            go_on = False
    if go_on:
        users_w = open("user_info.csv", "a", newline="")
        writer = csv.writer(users_w)
        new_user = [email, password, secret]
        writer.writerow(new_user)
        users_w.close()
        message.config(text="Mail registered Successfully!", fg="blue")
        message.place(x=60, y=450)
        message.after(9000, lambda: message.place_forget())


def user_signin():
    email = email_input.get()
    password = password_input.get()
    login = (users_data[all_mails == email])
    if len(login) == 0:
        notfound_label = Label(window, text="User not found. Try sign up!", fg="red", font=("Arial", 12))
        notfound_label.place(x=90, y=420)
        notfound_label.after(3000, lambda: notfound_label.place_forget())

    else:
        c_password = login["u_password"]
        if str(c_password[0]) == password:
            access()
        else:
            wrongpassword_label = Label(window, text="WRONG PASSWORD!", fg="red", font=("Arial", 12))
            wrongpassword_label.place(x=120, y=420)
            wrongpassword_label.after(3000, lambda: wrongpassword_label.place_forget())


def sign_in():
    email_input.delete(0, 'end')
    password_input.delete(0, 'end')
    secret_input.delete(0, 'end')

    secret_label.place_forget()

    secret_input.place_forget()

    signin_label.config(text="Sign In")
    signin_label.place(x=145, y=40)

    account_label.config(text="Don't have an account?")
    account_label.place(x=115, y=120)

    sign_up_label.config(text="Sign Up!")
    sign_up_label.pack()
    sign_up_label.bind("<Button-1>", lambda e: sign_up())
    sign_up_label.place(x=245, y=120)

    email_label.place(x=60, y=175)

    email_input.place(x=60, y=200)

    password_label.place(x=60, y=260)

    password_input.place(x=60, y=285)

    signin_button.config(text="Sign In", width=30, font=("Arial", 12), command=user_signin)
    signin_button.place(x=57, y=350)


def sign_up():
    email_input.delete(0, 'end')
    password_input.delete(0, 'end')
    secret_input.delete(0, 'end')

    signin_label.config(text="Sign Up")
    signin_label.place(x=145, y=40)

    account_label.config(text="Already have an account?")
    account_label.place(x=115, y=110)

    sign_up_label.config(text="Sign In!")
    sign_up_label.pack()
    sign_up_label.bind("<Button-1>", lambda e: sign_in())
    sign_up_label.place(x=245, y=110)

    email_label.place(x=60, y=150)

    email_input.place(x=60, y=175)

    password_label.place(x=60, y=215)

    password_input.place(x=60, y=240)

    secret_label.place(x=60, y=280)

    secret_input.place(x=60, y=305)

    signin_button.config(text="Sign Up", width=30, font=("Arial", 12), command=adding_user)
    signin_button.place(x=60, y=360)

# UI labels


signin_label = Label(window, text="Sign In", font=("Arial", 25))
account_label = Label(window, text="Don't have an account?")
sign_up_label = Label(window, text="Sign Up!", fg="blue", cursor="hand2")
email_label = Label(window, text="Email", font=("Arial", 12))
email_input = Entry(window, width=45)
password_label = Label(window, text="Password", font=("Arial", 12))
password_input = Entry(window, width=45)
signin_button = Button(text="Sign In", width=30, font=("Arial", 12), command=user_signin)
secret_label = Label(text="Secret", font=("Arial", 12))
secret_input = Entry(window, width=45)

sign_in()

window.mainloop()
