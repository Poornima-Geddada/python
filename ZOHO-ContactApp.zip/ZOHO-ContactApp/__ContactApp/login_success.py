from tkinter import *
from csv import reader
import csv


def save():
    t_window = Tk()
    t_window.geometry("770x700")
    t_window.minsize(770, 700)
    t_window.config(padx=20, pady=20)
    t_window.title("Contact form and contact list")

    title_label = Label(text="Contact Form and Contact list Page", font=("Arial", 23, "bold"))
    title_label.grid(row=0, column=0, columnspan=3, padx=90, pady=50)

    contact_label = Label(text="Contacts", font=("Arial", 15))
    contact_label.grid(row=1, column=1)

    name_label = Label(text="Name", font=("Arial", 12))
    name_label.grid(row=2, column=0, padx=20, pady=20)

    name_input = Entry(width=25, font=("Arial", 12))
    name_input.grid(row=2, column=1)

    phno_label = Label(text="Ph no", font=("Arial", 12))
    phno_label.grid(row=3, column=0, padx=20, pady=20)

    phno_input = Entry(width=25, font=("Arial", 12))
    phno_input.grid(row=3, column=1)

    email_label = Label(text="Email", font=("Arial", 12))
    email_label.grid(row=4, column=0, padx=20, pady=20)

    email_input = Entry(width=25, font=("Arial", 12))
    email_input.grid(row=4, column=1)

    def save_user():
        name = name_input.get()
        phno = phno_input.get()
        email = email_input.get()
        users_w = open("contacts_list.csv", "a", newline="")
        writer = csv.writer(users_w)
        if name == "" or phno == "" or email == "":
            contact_label.config(text="Enter all details", fg="red", font=("Arial", 12, "bold"))
            contact_label.after(3000, lambda: contact_label.config(text="Contacts", font=("Arial", 15), fg="black"))
        elif len(phno) != 10:
            contact_label.config(text="Enter proper phone number", fg="red", font=("Arial", 12, "bold"))
            contact_label.after(3000, lambda: contact_label.config(text="Contacts", font=("Arial", 15), fg="black"))
        elif email[-10::] != "@gmail.com":
            contact_label.config(text="Enter proper email", fg="red", font=("Arial", 12, "bold"))
            contact_label.after(3000, lambda: contact_label.config(text="Contacts", font=("Arial", 15), fg="black"))
        else:
            name_input.delete(0, 'end')
            phno_input.delete(0, 'end')
            email_input.delete(0, 'end')
            new_data = [name, phno, email]
            writer.writerow(new_data)
            users_w.close()
            table()

    save_button = Button(text="save", command=save_user, width=15)
    save_button.grid(row=5, column=1, padx=5, pady=50)


def table():
    data = []
    with open('contacts_list.csv', 'r') as u_list:
        csv_reader = reader(u_list)
        for row in csv_reader:
            t = (row[0], row[1], row[2])
            data.append(t)
    for i in range(len(data)):
        for j in range(3):
            e = Label(width=25, font=("Arial", 12), bg="white", borderwidth=2, relief="groove")
            if i == 0:
                e.config(bg="grey")
            e.grid(row=i+6, column=j)
            e.config(text=data[i][j])
    u_list.close()
