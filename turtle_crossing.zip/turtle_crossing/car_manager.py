import turtle
from turtle import Turtle
import random

STARTING_MOVE_DISTANCE = 5
MOVE_INCREMENT = 10


class CarManager:
    def __init__(self):
        turtle.colormode(255)
        self.all_cars = []
        self.car_speed = STARTING_MOVE_DISTANCE

    def to_make_a_car(self):
        random_number = random.randint(1, 6)
        if random_number == 1:
            color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
            body = Turtle(shape="square")
            body.shapesize(stretch_wid=1, stretch_len=2)
            body.penup()
            body.color(color)
            y_cords = random.randint(-250, 250)
            body.goto(300, y_cords)
            self.all_cars.append(body)

    def move(self):
        for seg in self.all_cars:
            seg.setheading(180)
            seg.forward(self.car_speed)

    def level_up(self):
        self.car_speed += MOVE_INCREMENT
